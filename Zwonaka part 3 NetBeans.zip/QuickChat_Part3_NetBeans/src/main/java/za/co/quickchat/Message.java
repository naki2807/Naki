package za.co.quickchat;

import java.util.UUID;

public class Message {
    private String messageId;
    private int messageNumber;
    private String recipient;
    private String text;
    private String hash;
    private String status;
    private String sender;

    public Message() { }

    public Message(String recipient, String text, int messageNumber, String sender, String status) {
        this.messageId = String.format("%010d", Math.abs(UUID.randomUUID().getMostSignificantBits() % 10_000_000_000L));
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.text = text;
        this.sender = sender == null ? "" : sender;
        this.status = status;
        this.hash = createMessageHash();
    }

    public boolean checkMessageID() { return messageId != null && messageId.length() <= 10; }

    public String checkMessageLength() {
        if (text == null) return "Message ready to send.";
        if (text.length() <= 250) return "Message ready to send.";
        return "Message exceeds 250 characters by " + (text.length() - 250) + "; please reduce the size.";
    }

    public String checkRecipientCell() {
        return recipient != null && recipient.matches("^\\+27[0-9]{9}$")
            ? "Cell phone number successfully captured."
            : "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String createMessageHash() {
        if (messageId == null || messageId.length() < 2 || text == null || text.isBlank()) return "";
        String[] words = text.trim().split("\\s+");
        String first = words[0].replaceAll("[^A-Za-z0-9]", "");
        String last = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        return messageId.substring(0, 2) + ":" + messageNumber + ":" + (first + last).toUpperCase();
    }

    public String SentMessage(String choice) {
        switch (choice == null ? "" : choice.trim().toLowerCase()) {
            case "1", "send", "sent" -> { status = "Sent"; return "Message successfully sent."; }
            case "2", "discard", "disregard" -> { status = "Disregarded"; return "Press 0 to delete the message."; }
            case "3", "store", "stored" -> { status = "Stored"; return "Message successfully stored."; }
            default -> { return "Invalid message option."; }
        }
    }

    public String printMessages() {
        return "Message ID: " + messageId + "\nMessage Hash: " + hash + "\nRecipient: " + recipient + "\nMessage: " + text;
    }

    public String getMessageId() { return messageId; }
    public int getMessageNumber() { return messageNumber; }
    public String getRecipient() { return recipient; }
    public String getText() { return text; }
    public String getHash() { return hash; }
    public String getStatus() { return status; }
    public String getSender() { return sender; }
    public void setStatus(String status) { this.status = status; }
    public void setMessageId(String messageId) { this.messageId = messageId; }
    public void setHash(String hash) { this.hash = hash; }
}
