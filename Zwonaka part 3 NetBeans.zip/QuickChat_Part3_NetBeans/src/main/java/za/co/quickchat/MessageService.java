package za.co.quickchat;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MessageService {
    private final List<Message> sentMessages = new ArrayList<>();
    private final List<Message> disregardedMessages = new ArrayList<>();
    private final List<Message> storedMessages = new ArrayList<>();
    private final List<String> messageHashes = new ArrayList<>();
    private final List<String> messageIds = new ArrayList<>();
    private final Path jsonFile;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private int nextMessageNumber = 0;

    public MessageService() { this(Path.of("messages.json")); }
    public MessageService(Path jsonFile) {
        this.jsonFile = jsonFile;
        loadStoredMessages();
        rebuildIndexes();
    }

    public Message create(String recipient, String text, String sender) {
        nextMessageNumber++;
        return new Message(recipient, text, nextMessageNumber, sender, "Pending");
    }

    public void add(Message message, String action) {
        if (message == null) return;
        String normalized = action == null ? "" : action.trim().toLowerCase();
        switch (normalized) {
            case "send", "sent", "1" -> sentMessages.add(message);
            case "discard", "disregard", "disregarded", "2" -> disregardedMessages.add(message);
            case "store", "stored", "3" -> { storedMessages.add(message); saveStoredMessages(); }
            default -> throw new IllegalArgumentException("Unknown message action: " + action);
        }
        messageHashes.add(message.getHash());
        messageIds.add(message.getMessageId());
    }

    public void saveStoredMessages() {
        try {
            Path parent = jsonFile.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Files.writeString(jsonFile, gson.toJson(storedMessages));
        } catch (IOException ex) {
            throw new IllegalStateException("Could not save messages to JSON: " + ex.getMessage(), ex);
        }
    }

    private void loadStoredMessages() {
        if (!Files.exists(jsonFile)) return;
        try {
            String json = Files.readString(jsonFile);
            Type type = new TypeToken<ArrayList<Message>>() {}.getType();
            List<Message> loaded = gson.fromJson(json, type);
            if (loaded != null) storedMessages.addAll(loaded);
        } catch (IOException | RuntimeException ex) {
            System.err.println("Warning: stored messages could not be loaded: " + ex.getMessage());
        }
    }

    private void rebuildIndexes() {
        for (Message m : storedMessages) {
            if (m.getHash() != null) messageHashes.add(m.getHash());
            if (m.getMessageId() != null) messageIds.add(m.getMessageId());
        }
    }

    public String displayStoredSendersAndRecipients() {
        if (storedMessages.isEmpty()) return "No stored messages.";
        StringBuilder out = new StringBuilder();
        for (Message m : storedMessages) out.append("Sender: ").append(m.getSender())
            .append(" | Recipient: ").append(m.getRecipient()).append(System.lineSeparator());
        return out.toString().trim();
    }

    public String longestStoredMessage() {
        return storedMessages.stream().map(Message::getText)
            .max((a, b) -> Integer.compare(a.length(), b.length())).orElse("No stored messages.");
    }

    public Optional<Message> searchById(String id) {
        return storedMessages.stream().filter(m -> m.getMessageId().equals(id)).findFirst();
    }

    public List<Message> searchByRecipient(String recipient) {
        List<Message> result = new ArrayList<>();
        for (Message m : storedMessages) if (m.getRecipient().equals(recipient)) result.add(m);
        return result;
    }

    public boolean deleteByHash(String hash) {
        boolean removed = storedMessages.removeIf(m -> m.getHash().equals(hash));
        if (removed) saveStoredMessages();
        return removed;
    }

    public String displayReport() {
        if (storedMessages.isEmpty()) return "No stored messages.";
        StringBuilder out = new StringBuilder("STORED MESSAGE REPORT\n");
        for (Message m : storedMessages) out.append("------------------------------\n")
            .append("Message Hash: ").append(m.getHash()).append('\n')
            .append("Recipient: ").append(m.getRecipient()).append('\n')
            .append("Message: ").append(m.getText()).append('\n')
            .append("Message ID: ").append(m.getMessageId()).append('\n')
            .append("Sender: ").append(m.getSender()).append('\n');
        return out.toString();
    }

    public int returnTotalMessagess() { return sentMessages.size(); }
    public Message[] getSentMessages() { return sentMessages.toArray(new Message[0]); }
    public Message[] getDisregardedMessages() { return disregardedMessages.toArray(new Message[0]); }
    public Message[] getStoredMessages() { return storedMessages.toArray(new Message[0]); }
    public String[] getMessageHashes() { return messageHashes.toArray(new String[0]); }
    public String[] getMessageIds() { return messageIds.toArray(new String[0]); }

    // Convenience sample loader matching the Part 3 brief; call only for demonstration/testing.
    public void loadPart3SampleData() {
        add(new Message("+27834557896", "Did you get the cake?", 1, "0838884567", "Sent"), "send");
        add(new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.", 2, "0838884567", "Stored"), "store");
        add(new Message("+27834484567", "Yohoooo, I am at your gate.", 3, "0838884567", "Disregarded"), "discard");
        add(new Message("0838884567", "It is dinner time !", 4, "0838884567", "Sent"), "send");
        add(new Message("+27838884567", "Ok, I am leaving without you.", 5, "0838884567", "Stored"), "store");
    }
}
