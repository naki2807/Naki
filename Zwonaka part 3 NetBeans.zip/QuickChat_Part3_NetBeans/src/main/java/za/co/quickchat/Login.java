package za.co.quickchat;

public class Login {
    private String username, password, cellPhone, firstName, lastName;

    public Login() { }
    public Login(String username, String password, String cellPhone, String firstName, String lastName) {
        this.username = username; this.password = password; this.cellPhone = cellPhone;
        this.firstName = firstName; this.lastName = lastName;
    }
    public boolean checkUserName() { return username != null && username.contains("_") && username.length() <= 5; }
    public boolean checkPasswordComplexity() {
        return password != null && password.length() >= 8
            && password.matches(".*[A-Z].*") && password.matches(".*[0-9].*")
            && password.matches(".*[^A-Za-z0-9].*");
    }
    // South African international format: +27 followed by exactly nine digits.
    public boolean checkCellPhoneNumber() { return cellPhone != null && cellPhone.matches("^\\+27[0-9]{9}$"); }

    public String registerUser() {
        if (!checkUserName()) return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        if (!checkPasswordComplexity()) return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        if (!checkCellPhoneNumber()) return "Cell phone number incorrectly formatted or does not contain international code.";
        return "Registration successful.";
    }
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return username != null && password != null && username.equals(enteredUsername) && password.equals(enteredPassword);
    }
    public String returnLoginStatus(boolean success) {
        return success ? "Welcome " + firstName + ", " + lastName + " it is great to see you again."
                       : "Username or password incorrect, please try again.";
    }
    public String getUsername() { return username; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
}
