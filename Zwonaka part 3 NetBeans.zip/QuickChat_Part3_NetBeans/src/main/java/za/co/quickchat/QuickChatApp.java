package za.co.quickchat;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class QuickChatApp {
    private static final Scanner INPUT = new Scanner(System.in);
    private static final MessageService SERVICE = new MessageService();
    private static Login account;

    public static void main(String[] args) {
        System.out.println("=================================");
        System.out.println("          QUICKCHAT");
        System.out.println("=================================");
        if (!registerAndLogin()) {
            System.out.println("Unable to log in. Goodbye.");
            return;
        }
        System.out.println("Welcome to QuickChat.");
        int count = readInt("How many messages would you like to enter? ", 0, 1000);
        int processed = 0;
        boolean running = true;
        while (running) {
            System.out.println("\nMAIN MENU\n1) Send Messages\n2) Show recently sent messages\n3) Quit\n4) Stored Messages");
            int choice = readInt("Choose an option: ", 1, 4);
            switch (choice) {
                case 1 -> {
                    if (processed >= count) System.out.println("You have reached the number of messages selected.");
                    else {
                        sendOneMessage();
                        processed++;
                    }
                }
                case 2 -> System.out.println("Coming Soon.");
                case 3 -> running = false;
                case 4 -> storedMenu();
                default -> System.out.println("Invalid option.");
            }
        }
        System.out.println("Total messages sent: " + SERVICE.returnTotalMessagess());
        System.out.println("Thank you for using QuickChat.");
    }

    private static boolean registerAndLogin() {
        System.out.println("Create your account");
        while (true) {
            String username = readLine("Username (underscore, max 5 characters): ");
            String password = readLine("Password: ");
            String phone = readLine("South African cell number (+27 followed by 9 digits): ");
            String first = readLine("First name: ");
            String last = readLine("Last name: ");
            account = new Login(username, password, phone, first, last);
            String status = account.registerUser();
            System.out.println(status);
            if (!status.equals("Registration successful.")) {
                System.out.println("Please enter your registration details again.");
                continue;
            }
            System.out.println("Login");
            String enteredUser = readLine("Username: ");
            String enteredPass = readLine("Password: ");
            boolean success = account.loginUser(enteredUser, enteredPass);
            System.out.println(account.returnLoginStatus(success));
            if (success) return true;
            return false;
        }
    }

    private static void sendOneMessage() {
        String recipient;
        do {
            recipient = readLine("Recipient number (+27 followed by 9 digits): ");
            if (!recipient.matches("^\\+27[0-9]{9}$")) System.out.println("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
        } while (!recipient.matches("^\\+27[0-9]{9}$"));
        String body;
        do {
            body = readLine("Enter your message (maximum 250 characters): ");
            if (body.length() > 250) System.out.println("Please enter a message of less than 250 characters.");
        } while (body.length() > 250);
        Message message = SERVICE.create(recipient, body, account.getUsername());
        System.out.println("Message ID generated: " + message.getMessageId());
        System.out.println("Message Hash: " + message.getHash());
        System.out.println("Choose: 1) Send Message  2) Disregard Message  3) Store Message");
        int action = readInt("Option: ", 1, 3);
        String actionName = action == 1 ? "send" : action == 2 ? "discard" : "store";
        System.out.println(message.SentMessage(String.valueOf(action)));
        SERVICE.add(message, actionName);
        System.out.println(message.printMessages());
    }

    private static void storedMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("\nSTORED MESSAGES\n1) Display sender and recipient\n2) Display longest stored message\n3) Search by message ID\n4) Search by recipient\n5) Delete by message hash\n6) Display full report\n7) Back");
            int choice = readInt("Choose an option: ", 1, 7);
            switch (choice) {
                case 1 -> System.out.println(SERVICE.displayStoredSendersAndRecipients());
                case 2 -> System.out.println("Longest message: " + SERVICE.longestStoredMessage());
                case 3 -> {
                    String id = readLine("Enter message ID: ");
                    Optional<Message> found = SERVICE.searchById(id);
                    System.out.println(found.map(m -> "Recipient: " + m.getRecipient() + "\nMessage: " + m.getText()).orElse("Message ID not found."));
                }
                case 4 -> {
                    String recipient = readLine("Enter recipient number: ");
                    List<Message> found = SERVICE.searchByRecipient(recipient);
                    if (found.isEmpty()) System.out.println("No messages found for this recipient.");
                    else for (Message m : found) System.out.println(m.printMessages());
                }
                case 5 -> {
                    String hash = readLine("Enter message hash: ");
                    System.out.println(SERVICE.deleteByHash(hash) ? "Message successfully deleted." : "Message hash not found.");
                }
                case 6 -> System.out.println(SERVICE.displayReport());
                case 7 -> back = true;
            }
        }
    }

    private static String readLine(String prompt) {
        System.out.print(prompt);
        return INPUT.nextLine().trim();
    }
    private static int readInt(String prompt, int min, int max) {
        while (true) {
            try {
                System.out.print(prompt);
                int value = Integer.parseInt(INPUT.nextLine().trim());
                if (value >= min && value <= max) return value;
            } catch (NumberFormatException ignored) { }
            System.out.println("Please enter a number from " + min + " to " + max + ".");
        }
    }
}
