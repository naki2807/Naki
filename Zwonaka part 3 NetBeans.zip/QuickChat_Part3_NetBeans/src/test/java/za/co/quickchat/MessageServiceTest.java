package za.co.quickchat;

import static org.junit.jupiter.api.Assertions.*;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class MessageServiceTest {
    @TempDir Path temp;
    @Test void storedMessagesPersistAndCanBeSearchedAndDeleted() throws Exception {
        Path json = temp.resolve("messages.json");
        MessageService service = new MessageService(json);
        Message m1 = service.create("+27838884567", "Where are you? You are late! I have asked you to be on time.", "sender");
        service.add(m1, "store");
        Message m2 = service.create("+27838884567", "Ok, I am leaving without you.", "sender");
        service.add(m2, "store");

        assertEquals(2, service.getStoredMessages().length);
        assertEquals(m1.getText(), service.longestStoredMessage());
        assertEquals(2, service.searchByRecipient("+27838884567").size());
        assertTrue(Files.exists(json));

        MessageService loaded = new MessageService(json);
        assertEquals(2, loaded.getStoredMessages().length);
        assertTrue(loaded.searchById(m1.getMessageId()).isPresent());
        assertTrue(loaded.deleteByHash(m1.getHash()));
        assertEquals(1, loaded.getStoredMessages().length);
    }

    @Test void sentAndDisregardedArraysArePopulated() {
        MessageService service = new MessageService(temp.resolve("none.json"));
        service.add(service.create("+27834557896", "Did you get the cake?", "sender"), "send");
        service.add(service.create("+27834484567", "Yohoooo, I am at your gate.", "sender"), "discard");
        assertEquals(1, service.getSentMessages().length);
        assertEquals(1, service.getDisregardedMessages().length);
        assertEquals(1, service.returnTotalMessagess());
    }

    @Test void recipientAndLengthMessagesMatchBrief() {
        Message valid = new Message("+27834557896", "Short message", 1, "sender", "Pending");
        assertEquals("Cell phone number successfully captured.", valid.checkRecipientCell());
        assertEquals("Message ready to send.", valid.checkMessageLength());
        Message invalid = new Message("08575975889", "x".repeat(251), 2, "sender", "Pending");
        assertTrue(invalid.checkRecipientCell().contains("incorrectly formatted"));
        assertEquals("Message exceeds 250 characters by 1; please reduce the size.", invalid.checkMessageLength());
    }

    @Test void messageLengthValidationAndHash() {
        Message m = new Message("+27834557896", "Hi Mike, can you join us for dinner tonight?", 1, "sender", "Pending");
        assertTrue(m.checkMessageID());
        assertTrue(m.getHash().matches("\\\\d{2}:1:HIMIKE|\\\\d{2}:1:HITONIGHT"));
    }
}
