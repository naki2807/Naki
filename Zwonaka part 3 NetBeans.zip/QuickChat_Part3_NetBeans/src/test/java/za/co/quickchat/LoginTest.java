package za.co.quickchat;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class LoginTest {
    @Test void usernameValidation() {
        assertTrue(new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Liv", "Muumba").checkUserName());
        assertFalse(new Login("kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976", "Liv", "Muumba").checkUserName());
    }
    @Test void passwordValidation() {
        assertTrue(new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Liv", "Muumba").checkPasswordComplexity());
        assertFalse(new Login("kyl_1", "password", "+27838968976", "Liv", "Muumba").checkPasswordComplexity());
    }
    @Test void phoneValidation() {
        assertTrue(new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Liv", "Muumba").checkCellPhoneNumber());
        assertFalse(new Login("kyl_1", "Ch&&sec@ke99!", "08966553", "Liv", "Muumba").checkCellPhoneNumber());
    }
    @Test void loginValidation() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Liv", "Muumba");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
        assertFalse(login.loginUser("kyl_1", "wrong"));
    }
}
